package soln.service1;

public class Service2 {

    private boolean isLeaking;
    
    public Service2(boolean isLeaking) {
        this.isLeaking = isLeaking;
    }

    public boolean LeakageDetector() {
        return isLeaking;
    }
    
    /**
     * If it is leaking this returns false meaning it wasn't repaired, if it is not leaking then return true meaning it was repaired
     * @return
     */
    public boolean repairChecker(){
        return !isLeaking;
    }
}
    

