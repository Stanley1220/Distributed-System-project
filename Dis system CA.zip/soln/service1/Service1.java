package soln.service1;

public class Service1 {

    boolean onSocket;
    

    public Service1(boolean onSocket) {
        this.onSocket = onSocket;
    }


    /** user will be able to have a control over water usage in their home */
    public void trackHomeWater(){

    }

    /**
     * User will be able to turn on the socket when water is needed and off when not
     * needed
     */
    public boolean socketBoxOnOff(){
        return !onSocket;
    }
    
}
