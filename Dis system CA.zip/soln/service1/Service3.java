package soln.service1;

public class Service3 {
    int temp;

    public Service3(int temp) {
        this.temp = temp;
    }

    public int bottleWaterTemp(){
        return temp;
    }

    public String dispenseWater(int temp){
        String tempType = temp < 20 ? "cold" : "hot";

        return "Dispensing " + tempType + " at " + temp + " temperature.";
    }
}
